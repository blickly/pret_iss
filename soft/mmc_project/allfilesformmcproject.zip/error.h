#ifndef ERROR_H
#define ERROR_H

typedef enum {
    NO_ERROR = 0,
    ERROR=1
}ErrorCode_t;

#endif
